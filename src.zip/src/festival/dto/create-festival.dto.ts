export class CreateFestivalDto {}
