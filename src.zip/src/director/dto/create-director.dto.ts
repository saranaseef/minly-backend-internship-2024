export class CreateDirectorDto {}
