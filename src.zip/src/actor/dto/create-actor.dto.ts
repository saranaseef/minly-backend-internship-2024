export class CreateActorDto {}
