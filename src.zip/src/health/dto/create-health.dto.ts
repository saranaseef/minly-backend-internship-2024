export class CreateHealthDto {}
