export class Health {}
